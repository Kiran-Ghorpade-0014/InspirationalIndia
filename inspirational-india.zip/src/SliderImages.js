import * as React from 'react';
import Card from './Components/Card';

export default function SliderImages() {
  
    return(
    < >
<section id='Section' >
  <div class="swiper">


   <Card/>
   <Card/>
   <Card/>
   <Card/>
   <Card/>
   <Card/>

{/*     
    <div class="swiper-wrapper">
      <div class="swiper-slide swiper-slide--one" >
        <span>domestic</span>
        <div>
          <h2>Enjoy the exotic of sunny Hawaii</h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            Maui, Hawaii
          </p>
        </div>
      </div>
      <div class="swiper-slide swiper-slide--two">
        <span>subtropical</span>
        <div>
          <h2>The Island of Eternal Spring</h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            Lanzarote, Spanien
          </p>
        </div>
      </div>

      <div class="swiper-slide swiper-slide--three">
        <span>history</span>
        <div>
          <h2>Awesome Eiffel Tower</h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            Paris, France
          </p>
        </div>
      </div>

      <div class="swiper-slide swiper-slide--four">
        <span>Mayans</span>
        <div>
          <h2>One of the safest states in Mexico</h2>
          <p>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            The Yucatan, Mexico
          </p>
        </div>
      </div>

      <div class="swiper-slide swiper-slide--five">
        <span>native</span>
        <div>
          <h2>The most popular yachting destination</h2>
          <p>

            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            Whitsunday Islands, Australia
          </p>
        </div>
      </div> */}

    {/* </div> */}
    <div class="swiper-pagination"></div>
  </div>
</section>
    </>
  );
}
